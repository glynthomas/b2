import { Component } from '@angular/core';

@Component({
    selector: 'brennan-upload',
    templateUrl: './upload.component.html',
    styleUrls: ['./upload.component.scss']
})
export class UploadComponent {
}
