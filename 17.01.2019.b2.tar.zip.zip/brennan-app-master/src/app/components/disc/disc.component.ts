import { Component } from '@angular/core';

@Component({
    selector: 'brennan-disc',
    templateUrl: './disc.component.html',
    styleUrls: ['./disc.component.scss']
})
export class DiscComponent {
}
