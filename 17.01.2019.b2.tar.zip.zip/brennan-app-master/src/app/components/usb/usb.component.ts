import { Component } from '@angular/core';

@Component({
    selector: 'brennan-usb',
    templateUrl: './usb.component.html',
    styleUrls: ['./usb.component.scss']
})
export class USBComponent {
}
