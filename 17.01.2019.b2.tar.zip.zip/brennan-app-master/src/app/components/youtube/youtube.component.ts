import { Component } from '@angular/core';

@Component({
  selector: 'brennan-youtube',
  templateUrl: './youtube.component.html',
  styleUrls: ['./youtube.component.scss']
})
export class YouTubeComponent {
}
