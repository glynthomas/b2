import { Component } from '@angular/core';

@Component({
    selector: 'brennan-playlist-panel',
    templateUrl: './playlist-panel.component.html',
    styleUrls: ['./playlist-panel.component.scss']
})
export class PlaylistPanelComponent {
}
