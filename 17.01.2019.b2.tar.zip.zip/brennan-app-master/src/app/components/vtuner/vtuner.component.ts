import { Component } from '@angular/core';

@Component({
  selector: 'brennan-vtuner',
  templateUrl: './vtuner.component.html',
  styleUrls: ['./vtuner.component.scss']
})
export class VTunerComponent {
}
