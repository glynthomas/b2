export class BrennanPreset {
    name: string;
    url: string;
}