export class BrennanSearchItem {
    id: number;
    artist?: string;
    album?: string;
    track?: string;
    radio?: string;
    video?: string;
}