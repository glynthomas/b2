export class BrennanAlbum {
    id: number;
    name: string;
}