export class BrennanTrack {
    id: number;
    name: string;
}