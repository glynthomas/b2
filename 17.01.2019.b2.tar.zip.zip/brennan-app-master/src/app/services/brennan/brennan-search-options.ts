export interface BrennanSearchOptions {
    artists: boolean;
    albums: boolean;
    tracks: boolean;
    radio: boolean;
    video: boolean;
}