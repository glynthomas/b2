export class BrowseAlbum {
    id: number;
    name: string;
}