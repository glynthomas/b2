export class BrowseTrack {
    id: number;
    name: string;
}