export class BrowseArtist {
    id: number;
    name: string;
}