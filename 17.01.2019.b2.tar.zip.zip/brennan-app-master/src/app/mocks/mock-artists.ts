import { BrennanSearchItem } from '../services/brennan/brennan-search-item';

export const RESULTS: BrennanSearchItem[] = [
    { id: 11, artist: '10,000 Maniacs' },
    { id: 12, artist: 'AC-DC' },
    { id: 13, artist: 'Adele' },
    { id: 14, artist: 'Alanis Morissette' },
    { id: 15, artist: 'Alison Krauss' },
    { id: 16, artist: 'Alison Moyet' }

]